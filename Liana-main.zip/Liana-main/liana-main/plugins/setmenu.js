let handler  = async (m, { conn, command, text }) => {
  let type = command.replace(/^set(menu|help|\?)/, '').toLowerCase()
  if (type == '') {
    if (text) {
      conn.menu = text
      conn.reply(m.chat, 'Menu configurado corretamente\n' + info, m)
    } else {
      conn.menu = {}
      conn.reply(m.chat, 'Menu Reiniciado', m)
    }
  } else {
    conn.menu = typeof conn.menu == 'object' ? conn.menu : {}
    if (text) {
      conn.menu[type] = text
      conn.reply(m.chat, 'Menu ' + type + ' Configurado corretamente\n' + info, m)
    } else {
      delete conn.menu[type]
      conn.reply(m.chat, 'Menu ' + type + 'Menu Reiniciado', m)
    }
  }
}
handler.help = ['', 'before','header','body','footer','after'].map(v => 'setmenu' + v + ' <Texto>')
handler.tags = ['owner']
handler.command = /^set(menu|help|\?)(before|header|body|footer|after)?$/i
handler.owner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

let info = `
Universal:
%% (%)
%p (Prefixo)
%exp (Xp)
%limit (Limite)
%name (Nome)
%weton (Hoje)
%week (Semana)
%date (Data)
%time (Tempo)
%uptime (Tempo de atividade da bot)
%totalreg (O número de usuários no banco de dados)
%npmname
%npmdesc
%version
%github

Ordem:
%category (Kategori)

Algumas Funções:
%cmd (Comando)
%islimit (Se o comando for limitado)
`.trim()

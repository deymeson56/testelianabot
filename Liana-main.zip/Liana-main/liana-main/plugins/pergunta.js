let handler = async (m, { conn, text }) => {
  conn.reply(m.chat, `
*Pergunta:* ${m.text}
*Resposta:* ${pickRandom(['Sim', 'Talvez sim', 'Pode ser', 'Talvez não', 'Não', 'De maneira nenhuma','Será??'])}
`.trim(), m)
}
handler.help = ['pergunta <Pergunta>?']
handler.tags = ['kerang']
handler.customPrefix = /(\?$)/
handler.command = /^apakah$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

